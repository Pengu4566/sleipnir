Non repetative framework.

Intended for simple scripts which execute processes that cannot be said to be "transactional.